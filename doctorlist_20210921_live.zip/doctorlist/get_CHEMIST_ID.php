<?php
// Include the database connection file
include('connection.php');

if (isset($_POST['CHEMIST_ID']) && !empty($_POST['CHEMIST_ID'])) {
    
    $X = $_POST['CHEMIST_ID'];
    
    echo $X;
	// Fetch state name base on country id
	
//	$query = 'select * from skf_thana where DIST LIKE "%'.$X.'%"  ' ;
//	$query = 'SELECT * FROM skf_customer_information WHERE THANANAME LIKE "%'.$X.'%" ';
	$query = 'SELECT * FROM skf_customer_information WHERE MSOTR LIKE "%'.$X.'%" ';
//	$query = "SELECT * FROM skf_4p WHERE CH_THA LIKE "%'.$X.'%"  ";
	$result = $conn->query($query);

	if ($result->num_rows > 0) {
		echo '<option value="">Select CHEMIST ID</option>'; 
		while ($row = $result->fetch_assoc()) {
		//    echo '<option value="'.$row["DRID_4P"].'">'.$row["DRID_4P"].'</option>';
			echo '<option value="'.$row["IDCUST"]." - ".$row["NAMECUST"]." - ".$row["MARKETNAME"].' ">'.$row["IDCUST"]." - ".$row["NAMECUST"]." - ".$row["MARKETNAME"].'</option>'; 
			
			
		}
	} else {
		echo '<option value="">CHEMIST not available</option>'; 
	}
} 


?>