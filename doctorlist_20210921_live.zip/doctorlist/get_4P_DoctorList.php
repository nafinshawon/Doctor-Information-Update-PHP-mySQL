<?php
// Include the database connection file
include('connection.php');

if (isset($_POST['DRID_4P_ID']) && !empty($_POST['DRID_4P_ID'])) {
    
    $X = $_POST['DRID_4P_ID'];
    
    echo $X;
	// Fetch state name base on country id
	
//	$query = 'select * from skf_thana where DIST LIKE "%'.$X.'%"  ' ;
	$query = "SELECT * FROM skf_4p WHERE CH_THA = '$X' order by DRNAME_4P ";
//	$query = "SELECT * FROM skf_4p WHERE CH_THA LIKE "%'.$X.'%"  ";
	$result = $conn->query($query);

	if ($result->num_rows > 0) {
		echo '<option value="">Select 4P</option>'; 
		while ($row = $result->fetch_assoc()) {
		//    echo '<option value="'.$row["DRID_4P"].'">'.$row["DRID_4P"].'</option>';
			echo '<option value="'.$row["DRID_4P"].'">'.$row["DRID_4P"]." - ".$row["DRNAME_4P"]." - ".$row["CH_ADD"].'</option>'; 
			
			//$data[] = $row["DRID_4P"]." - ".$row["DRNAME_4P"]." - ".$row["CH_ADD"];
		}
	} else {
		echo '<option value="">4P Doctor not available</option>'; 
	}
} 


?>